# pip install confluent_kafka
# pip install --no-binary :all: confluent-kafka
# https://github.com/confluentinc/confluent-kafka-python

from confluent_kafka import Consumer, KafkaError

c = Consumer({
    'client.id': 'dochi',
    'group.id': 'local-group',
    'bootstrap.servers': 'localhost:9093',
    'auto.offset.reset': 'latest',
    'security.protocol': 'SASL_PLAINTEXT',
    'sasl.mechanism': 'PLAIN',
    'sasl.username': 'dochi',
    'sasl.password': 'dochi',
})

c.subscribe(['local-topic'])

while True:
    msg = c.poll(0.1)

    if msg is None:
        continue
    if msg.error():
        print( msg.error() )
        continue
        
    message = msg.value().decode('utf-8')

    print( message )

c.close()